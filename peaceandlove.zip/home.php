<html>
    
    
   <a class="text-light" href="post_news.php">SEE UPDATED NEWS</a></span></h2>
   
     <a class="text-light" href="post.php">SEE UPDATED NEWS</a></span></h2>
     
</html>